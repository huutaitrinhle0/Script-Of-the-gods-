# Owner Key • N/A TIME • Roblox

This package adds a server-authoritative Roblox key gate for the existing Vercel/Upstash key API.

## What it does

- Owner keys can be created with `mode: "na_time"` and never expire (`expiresAt: null`).
- The Roblox server derives `ownerId` from `Player.UserId`; the client cannot choose another owner ID.
- A stolen Owner key does not grant Owner commands to another Roblox account.
- Invalid, expired, revoked, or ownership-mismatched keys cause the player to be kicked.
- Owner-only commands:
  - `!kickfake` / `!kickunverified` — kicks players who have not passed server-side key verification.
  - `!kick <UserId|Name|DisplayName> <reason>` — kick a player.
  - `!verify <UserId|Name|DisplayName>` — show verification state through an attribute.
- The server applies a local cooldown to verification and command requests.

## Setup

1. Deploy the existing Vercel key API.
2. In `OwnerKeyGuard.server.lua`, replace `VERIFY_URL` with your `/api/verify` URL.
3. Set `OWNER_USER_ID` to the owner's Roblox UserId.
4. In Roblox Studio, enable `Game Settings -> Security -> Allow HTTP Requests`.
5. Put `OwnerKeyGuard.server.lua` in `ServerScriptService`.
6. Put `OwnerKeyClient.local.lua` in `StarterPlayerScripts`, then connect your own key UI to `_G.OwnerKeySubmit`.
7. Generate the permanent key using the API with the owner's Roblox UserId:

```json
POST /api/generate
Authorization: Bearer YOUR_ADMIN_TOKEN
Content-Type: application/json

{
  "ownerId": "123456789",
  "mode": "na_time"
}
```

The `ownerId` must match the owner Roblox `UserId`.

## Security note

Do not put `KEY_ADMIN_TOKEN`, Redis tokens, or any server secret inside a LocalScript or public GitHub repository. The Roblox client is not a trusted environment. Owner authorization is checked on the server.
