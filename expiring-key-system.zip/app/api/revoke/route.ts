import { NextResponse } from "next/server";
import { redis, recordKey } from "@/lib/store";

export const runtime = "nodejs";

function authorized(request: Request) {
  const provided = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  return Boolean(provided && provided === process.env.KEY_ADMIN_TOKEN);
}

export async function POST(request: Request) {
  if (!authorized(request)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const key = String(body?.key ?? "").trim().toUpperCase();

    if (!key) {
      return NextResponse.json({ error: "key is required" }, { status: 400 });
    }

    const deleted = await redis.del(recordKey(key));

    return NextResponse.json({
      ok: true,
      revoked: deleted > 0
    });
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
}