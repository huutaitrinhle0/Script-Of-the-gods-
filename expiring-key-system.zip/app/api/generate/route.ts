import { NextResponse } from "next/server";
import { redis, recordKey } from "@/lib/store";
import { generateKey, getDurationSeconds, type KeyUnit } from "@/lib/key";

export const runtime = "nodejs";

function authorized(request: Request) {
  const provided = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  return Boolean(provided && provided === process.env.KEY_ADMIN_TOKEN);
}

export async function POST(request: Request) {
  if (!authorized(request)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const duration = Number(body?.duration);
    const unit = body?.unit as KeyUnit;

    if (!["hours", "days"].includes(unit)) {
      return NextResponse.json({ error: "unit must be hours or days" }, { status: 400 });
    }

    const ttl = getDurationSeconds(duration, unit);
    const key = generateKey();
    const now = Date.now();
    const expiresAt = now + ttl * 1000;

    await redis.set(
      recordKey(key),
      { createdAt: now, expiresAt },
      { ex: ttl }
    );

    return NextResponse.json({
      ok: true,
      key,
      createdAt: new Date(now).toISOString(),
      expiresAt: new Date(expiresAt).toISOString(),
      expiresInSeconds: ttl,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Invalid request";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}