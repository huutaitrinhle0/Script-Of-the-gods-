import { NextResponse } from "next/server";
import { redis, recordKey, rateKey, type KeyRecord } from "@/lib/store";

export const runtime = "nodejs";

const RATE_LIMIT = 30;

function getClientIp(request: Request) {
  return request.headers.get("x-forwarded-for")?.split(",")[0]?.trim()
    || request.headers.get("x-real-ip")
    || "unknown";
}

export async function POST(request: Request) {
  const ip = getClientIp(request);
  const limiter = rateKey(ip);

  const count = await redis.incr(limiter);
  if (count === 1) {
    await redis.expire(limiter, 60);
  }

  if (count > RATE_LIMIT) {
    return NextResponse.json(
      { valid: false, error: "Too many requests. Try again later." },
      { status: 429 }
    );
  }

  try {
    const body = await request.json();
    const key = String(body?.key ?? "").trim().toUpperCase();

    if (!key || key.length < 10) {
      return NextResponse.json({ valid: false, error: "Invalid key." }, { status: 400 });
    }

    const record = await redis.get<KeyRecord>(recordKey(key));

    if (!record) {
      return NextResponse.json({
        valid: false,
        status: "expired_or_invalid",
        message: "Key is invalid or has expired."
      });
    }

    const now = Date.now();

    if (record.expiresAt <= now) {
      await redis.del(recordKey(key));
      return NextResponse.json({
        valid: false,
        status: "expired",
        message: "Key has expired."
      });
    }

    return NextResponse.json({
      valid: true,
      status: "active",
      expiresAt: new Date(record.expiresAt).toISOString(),
      expiresInSeconds: Math.max(0, Math.floor((record.expiresAt - now) / 1000))
    });
  } catch {
    return NextResponse.json({ valid: false, error: "Invalid request." }, { status: 400 });
  }
}