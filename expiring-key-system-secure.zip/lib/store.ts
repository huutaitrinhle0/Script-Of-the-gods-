import { Redis } from "@upstash/redis";
import { createHash } from "node:crypto";

const redis = Redis.fromEnv();

export type KeyRecord = {
  createdAt: number;
  expiresAt: number;
};

export function keyHash(key: string) {
  return createHash("sha256").update(key, "utf8").digest("hex");
}

export function recordKey(key: string) {
  return `key:${keyHash(key)}`;
}

export function rateKey(ip: string) {
  return `rate:${createHash("sha256").update(ip).digest("hex")}`;
}

export { redis };