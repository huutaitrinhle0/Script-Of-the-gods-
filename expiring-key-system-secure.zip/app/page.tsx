 "use client";

import { FormEvent, useState } from "react";

type Generated = {
  key: string;
  expiresAt: string;
};

export default function Home() {
  const [duration, setDuration] = useState("24");
  const [unit, setUnit] = useState<"hours" | "days">("hours");
  const [adminToken, setAdminToken] = useState("");
  const [generated, setGenerated] = useState<Generated | null>(null);
  const [verifyKey, setVerifyKey] = useState("");
  const [verifyResult, setVerifyResult] = useState<string>("");
  const [revokeKey, setRevokeKey] = useState("");
  const [message, setMessage] = useState("");

  async function generate(e: FormEvent) {
    e.preventDefault();
    setMessage("");
    setGenerated(null);

    const res = await fetch("/api/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify({ duration: Number(duration), unit }),
    });

    const data = await res.json();
    if (!res.ok) {
      setMessage(data.error ?? "Generate failed");
      return;
    }

    setGenerated({ key: data.key, expiresAt: data.expiresAt });
  }

  async function verify(e: FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key: verifyKey }),
    });

    const data = await res.json();
    setVerifyResult(
      data.valid
        ? `VALID — expires ${new Date(data.expiresAt).toLocaleString()}`
        : `INVALID — ${data.message ?? data.error ?? "Key rejected"}`
    );
  }

  async function revoke(e: FormEvent) {
    e.preventDefault();
    setMessage("");

    const res = await fetch("/api/revoke", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify({ key: revokeKey }),
    });

    const data = await res.json();
    setMessage(
      res.ok
        ? data.revoked ? "Key revoked." : "Key was not found."
        : (data.error ?? "Revoke failed")
    );
  }

  return (
    <main className="wrap">
      <section className="hero">
        <span className="badge">SELF-HOSTED KEY SYSTEM</span>
        <h1>Expiring Keys</h1>
        <p>Create keys that automatically expire after a chosen number of hours or days.</p>
      </section>

      <div className="grid">
        <section className="card">
          <h2>Generate</h2>
          <form onSubmit={generate}>
            <label>Admin token</label>
            <input type="password" value={adminToken} onChange={e => setAdminToken(e.target.value)} placeholder="Server-side secret" required />
            <div className="row">
              <div>
                <label>Duration</label>
                <input type="number" min="1" value={duration} onChange={e => setDuration(e.target.value)} required />
              </div>
              <div>
                <label>Unit</label>
                <select value={unit} onChange={e => setUnit(e.target.value as "hours" | "days")}>
                  <option value="hours">Hours</option>
                  <option value="days">Days</option>
                </select>
              </div>
            </div>
            <button type="submit">Generate Key</button>
          </form>

          {generated && (
            <div className="result">
              <strong>{generated.key}</strong>
              <span>Expires: {new Date(generated.expiresAt).toLocaleString()}</span>
            </div>
          )}
        </section>

        <section className="card">
          <h2>Verify</h2>
          <form onSubmit={verify}>
            <label>Key</label>
            <input value={verifyKey} onChange={e => setVerifyKey(e.target.value)} placeholder="KEY-XXXXXX-XXXXXX-XXXXXX" required />
            <button type="submit">Verify Key</button>
          </form>
          {verifyResult && <div className="result">{verifyResult}</div>}
        </section>

        <section className="card">
          <h2>Revoke</h2>
          <form onSubmit={revoke}>
            <label>Admin token</label>
            <input type="password" value={adminToken} onChange={e => setAdminToken(e.target.value)} required />
            <label>Key</label>
            <input value={revokeKey} onChange={e => setRevokeKey(e.target.value)} placeholder="Key to revoke" required />
            <button className="danger" type="submit">Revoke Key</button>
          </form>
        </section>
      </div>

      {message && <div className="toast">{message}</div>}
    </main>
  );
}