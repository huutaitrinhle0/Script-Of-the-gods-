import { NextResponse } from "next/server";
import { redis, recordKey, type KeyRecord } from "@/lib/store";
import {
  allowedOrigin,
  blockedByRateLimit,
  bodyIsSmall,
  isJson,
  requestIp,
} from "@/lib/security";

export const runtime = "nodejs";

function fail(message: string, status = 400) {
  return NextResponse.json(
    { valid: false, error: message },
    { status, headers: { "Cache-Control": "no-store" } }
  );
}

export async function POST(request: Request) {
  if (!isJson(request)) return fail("Content-Type must be application/json.", 415);
  if (!bodyIsSmall(request)) return fail("Request body too large.", 413);
  if (!allowedOrigin(request)) return fail("Origin is not allowed.", 403);

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return fail("Malformed JSON.");
  }

  const key = String(
    body && typeof body === "object" && "key" in body
      ? (body as { key?: unknown }).key ?? ""
      : ""
  ).trim().toUpperCase();

  // Strict format: the server itself creates KEY-XXXXXX-XXXXXX-XXXXXX.
  if (!/^KEY-[A-Z0-9]{6}(?:-[A-Z0-9]{6}){2}$/.test(key)) {
    return fail("Invalid key format.");
  }

  if (await blockedByRateLimit(request, key)) {
    return NextResponse.json(
      { valid: false, error: "Too many requests. Try again later." },
      { status: 429, headers: { "Retry-After": "60" } }
    );
  }

  // Avoid cache/replay through intermediaries.
  const result = await redis.get<KeyRecord>(recordKey(key));
  const now = Date.now();

  if (!result) {
    return fail("Key is invalid or has expired.", 404);
  }

  if (result.expiresAt <= now) {
    await redis.del(recordKey(key));
    return fail("Key has expired.", 410);
  }

  return NextResponse.json(
    {
      valid: true,
      status: "active",
      expiresAt: new Date(result.expiresAt).toISOString(),
      expiresInSeconds: Math.max(0, Math.floor((result.expiresAt - now) / 1000)),
    },
    {
      headers: {
        "Cache-Control": "no-store, max-age=0",
        "X-Request-IP-Tracked": requestIp(request) ? "true" : "false",
      },
    }
  );
}
