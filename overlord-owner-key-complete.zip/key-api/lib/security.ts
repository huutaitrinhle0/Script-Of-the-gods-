import { timingSafeEqual } from "node:crypto";
import { createHash } from "node:crypto";
import { redis } from "@/lib/store";

const WINDOW_SECONDS = 60;
const IP_LIMIT = 30;
const KEY_LIMIT = 10;
const MAX_BODY_BYTES = 1024;

function digest(value: string) {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

function sameSecret(a: string | null, b: string | undefined) {
  if (!a || !b) return false;
  const aa = Buffer.from(a, "utf8");
  const bb = Buffer.from(b, "utf8");
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}

export function authorizedAdmin(request: Request) {
  const provided = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? null;
  return sameSecret(provided, process.env.KEY_ADMIN_TOKEN);
}

export function requestIp(request: Request) {
  // x-forwarded-for is the normal proxy header used by Vercel.
  return request.headers.get("x-forwarded-for")?.split(",")[0]?.trim()
    || request.headers.get("x-real-ip")
    || "unknown";
}

export function bodyIsSmall(request: Request) {
  const length = Number(request.headers.get("content-length") ?? "0");
  return !Number.isFinite(length) || length <= MAX_BODY_BYTES;
}

export function isJson(request: Request) {
  const type = request.headers.get("content-type") ?? "";
  return type.toLowerCase().startsWith("application/json");
}

async function hitLimit(namespace: string, value: string, limit: number) {
  const key = `rl:${namespace}:${digest(value)}`;
  const count = await redis.incr(key);
  if (count === 1) await redis.expire(key, WINDOW_SECONDS);
  return count > limit;
}

export async function blockedByRateLimit(request: Request, key?: string) {
  const ip = requestIp(request);
  if (await hitLimit("ip", ip, IP_LIMIT)) return true;
  if (key && await hitLimit("key", key, KEY_LIMIT)) return true;
  return false;
}

export function allowedOrigin(request: Request) {
  const configured = process.env.ALLOWED_ORIGIN;
  if (!configured) return true;

  const origin = request.headers.get("origin");
  if (!origin) return true; // Non-browser clients may omit Origin.
  return origin === configured;
}
