import { randomBytes } from "node:crypto";

export const UNITS = {
  hours: 60 * 60,
  days: 24 * 60 * 60,
} as const;

export type KeyUnit = keyof typeof UNITS;

export function generateKey() {
  const raw = randomBytes(18).toString("hex").toUpperCase();
  const parts = raw.match(/.{1,6}/g) ?? [raw];
  return `KEY-${parts.join("-")}`;
}

export function getDurationSeconds(duration: number, unit: KeyUnit) {
  if (!Number.isFinite(duration) || duration <= 0) {
    throw new Error("Duration must be greater than 0.");
  }

  const seconds = duration * UNITS[unit];
  if (!Number.isSafeInteger(seconds)) {
    throw new Error("Duration is too large.");
  }

  return seconds;
}

export function normalizeOwnerId(value: unknown) {
  const ownerId = String(value ?? "").trim();
  if (!ownerId || ownerId.length > 128) {
    throw new Error("ownerId is required and must be 1-128 characters.");
  }
  // Keep owner IDs opaque and safe for JSON/storage.
  if (!/^[A-Za-z0-9._:@-]+$/.test(ownerId)) {
    throw new Error("ownerId contains unsupported characters.");
  }
  return ownerId;
}