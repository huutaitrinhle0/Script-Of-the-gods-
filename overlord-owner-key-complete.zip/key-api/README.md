# Expiring Key System

A self-hosted key system for your own application/script.

## Features

- Generate keys for `X` hours or `X` days.
- Server-side expiration using Redis TTL.
- Verify active/expired keys through an API.
- Revoke keys immediately.
- Keys are stored by SHA-256 hash instead of the raw key.
- Basic per-IP verification rate limit.
- Vercel/Next.js friendly.

## 1. Install

```bash
npm install
```

## 2. Environment variables

Copy `.env.example` to `.env.local` and fill in:

```env
UPSTASH_REDIS_REST_URL=...
UPSTASH_REDIS_REST_TOKEN=...
KEY_ADMIN_TOKEN=use-a-long-random-secret
```

For Vercel, add the same values in Project Settings → Environment Variables.

## 3. Run

```bash
npm run dev
```

Open `http://localhost:3000`.

## API

### Generate

`POST /api/generate`

Header:

```http
Authorization: Bearer YOUR_ADMIN_TOKEN
Content-Type: application/json
```

Body:

```json
{
  "duration": 24,
  "unit": "hours"
}
```

or:

```json
{
  "duration": 7,
  "unit": "days"
}
```

Response contains the newly generated key and exact expiry timestamp.

### Verify

`POST /api/verify`

```json
{
  "key": "KEY-XXXXXX-XXXXXX-XXXXXX"
}
```

Returns `valid: true` while the key exists and has not expired.

### Revoke

`POST /api/revoke`

Header:

```http
Authorization: Bearer YOUR_ADMIN_TOKEN
Content-Type: application/json
```

Body:

```json
{
  "key": "KEY-XXXXXX-XXXXXX-XXXXXX"
}
```

## Deploy to Vercel

1. Push this project to your own GitHub repository.
2. Import the repository into Vercel.
3. Add the environment variables.
4. Deploy.

Do not put `KEY_ADMIN_TOKEN` in frontend code or commit `.env.local` to GitHub.

## Important

GitHub is used for source code. Redis is used for the live key database. This keeps expiration and revocation server-side instead of trusting client-side timers.


## Anti-spam / fake-request protection

The API now adds several server-side controls:

- Per-IP rate limiting.
- Additional per-key rate limiting on `/api/verify`.
- Strict JSON `Content-Type`.
- Maximum request-body size.
- Strict key format validation.
- Optional `ALLOWED_ORIGIN` browser-origin restriction.
- Constant-time comparison for the admin token.
- `Cache-Control: no-store` to reduce replay/caching issues.

No client-side system can make a public API completely immune to fake requests. These controls are designed to make automated abuse substantially harder while keeping legitimate verification usable.
