# Owner Key — N/A TIME

## Roblox installation

1. Put `OwnerKeyGuard.server.lua` in `ServerScriptService`.
2. Put `OwnerKeyClient.local.lua` in `StarterPlayer > StarterPlayerScripts`.
3. In `OwnerKeyGuard.server.lua`, replace `VERIFY_URL` with your deployed `/api/verify` URL.
4. Replace `OWNER_USER_ID` with the Owner's Roblox UserId.
5. Enable **Game Settings → Security → Allow HTTP Requests**.

The server derives `Player.UserId` itself and sends it to the API. The client cannot choose its owner ID or grant itself Owner.

## Owner commands

- `F8` — server-authorized `!kickfake` shortcut.
- `!kickfake` / `!kickunverified` — remove players that have not passed server verification.
- `!kick <UserId|Name> <reason>` — Owner-only kick.
- `!verify <UserId|Name>` — Owner-only verification status check.

A key generated with `mode: "na_time"` has `expiresAt: null` and is permanent until revoked.
