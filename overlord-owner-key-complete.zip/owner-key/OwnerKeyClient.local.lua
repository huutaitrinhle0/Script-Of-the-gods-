-- OwnerKeyClient.local.lua
-- Put this LocalScript in StarterPlayerScripts or inside your key UI.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local player = Players.LocalPlayer

local remotes = ReplicatedStorage:WaitForChild("OwnerKeyRemotes")
local submitEvent = remotes:WaitForChild("OwnerKey_Submit")
local commandEvent = remotes:WaitForChild("OwnerKey_Command")

local function submitKey(key)
	submitEvent:FireServer(key)
end

-- Replace this with your own UI input button.
-- Example:
-- submitKey("KEY-AAAAAA-BBBBBB-CCCCCC")

-- Owner-only command helper. Server checks ownership again.
local function ownerCommand(text)
	commandEvent:FireServer(text)
end

-- Example commands:
-- ownerCommand("!kickfake")
-- ownerCommand("!kick 123456789 Fake key")

-- Expose helpers to your UI code.
_G.OwnerKeySubmit = submitKey
_G.OwnerKeyCommand = ownerCommand

player:GetAttributeChangedSignal("KeyVerified"):Connect(function()
	-- Your UI can react here.
	-- true = verified, false = not verified.
end)
